-- ============================================
-- CONSULTAS SQL - DASHBOARD ANALÍTICO
-- Grupo 4: Institución Universitaria
-- Analista de BI y Visualización: Marianny
-- ============================================


-- ============================================
-- PREGUNTA 1
-- ¿Qué carreras, cursos o sedes concentran 
-- la mayor matrícula por periodo académico?
-- ============================================

SELECT
  dc.nombre_carrera,
  dc.nombre_curso,
  dt.periodo_academico,
  dt.anio,
  COUNT(*) AS total_matriculas
FROM fact_rendimiento fr
JOIN dim_curso dc ON fr.sk_curso = dc.sk_curso
JOIN dim_tiempo dt ON fr.sk_tiempo = dt.sk_tiempo
GROUP BY dc.nombre_carrera, dc.nombre_curso, dt.periodo_academico, dt.anio
ORDER BY total_matriculas DESC;


-- ============================================
-- PREGUNTA 2
-- ¿Cómo se comportan la aprobación, reprobación 
-- y deserción según curso, docente y cohorte?
-- ============================================

SELECT
  dc.nombre_curso,
  dd.nombre_completo AS docente,
  de.anio_ingreso AS cohorte,
  SUM(fr.es_aprobado) AS aprobados,
  SUM(fr.es_desercion) AS deserciones,
  COUNT(*) - SUM(fr.es_aprobado) - SUM(fr.es_desercion) AS reprobados,
  COUNT(*) AS total
FROM fact_rendimiento fr
JOIN dim_curso dc ON fr.sk_curso = dc.sk_curso
JOIN dim_docente dd ON fr.sk_docente = dd.sk_docente
JOIN dim_estudiante de ON fr.sk_estudiante = de.sk_estudiante
GROUP BY dc.nombre_curso, dd.nombre_completo, de.anio_ingreso
ORDER BY dc.nombre_curso, de.anio_ingreso;


-- ============================================
-- PREGUNTA 3
-- ¿Qué perfiles de estudiante muestran mayor 
-- riesgo académico o abandono?
-- ============================================

SELECT
  de.genero,
  de.colegio_procedencia,
  de.anio_ingreso AS cohorte,
  COUNT(*) AS total_matriculas,
  SUM(fr.es_desercion) AS deserciones,
  ROUND(AVG(fr.nota_final), 2) AS nota_promedio,
  ROUND(100.0 * SUM(fr.es_desercion) / COUNT(*), 1) AS tasa_desercion
FROM fact_rendimiento fr
JOIN dim_estudiante de ON fr.sk_estudiante = de.sk_estudiante
GROUP BY de.genero, de.colegio_procedencia, de.anio_ingreso
ORDER BY tasa_desercion DESC;


-- ============================================
-- PREGUNTA 4
-- ¿Cuáles franjas horarias, modalidades o campus 
-- presentan mejor aprovechamiento y demanda?
-- ============================================

SELECT
  go.modalidad,
  go.franja_horaria,
  s.nombre_sede,
  COUNT(*) AS total_matriculas,
  ROUND(AVG(fr.nota_final), 2) AS nota_promedio,
  ROUND(100.0 * SUM(fr.es_aprobado) / COUNT(*), 1) AS tasa_aprobacion
FROM fact_rendimiento fr
JOIN Matricula m ON fr.sk_estudiante IN (
  SELECT sk_estudiante FROM dim_estudiante de2
  WHERE de2.id_estudiante = m.id_estudiante
)
JOIN Grupo_Oferta go ON m.id_grupo = go.id_grupo
JOIN Sede s ON go.id_sede = s.id_sede
GROUP BY go.modalidad, go.franja_horaria, s.nombre_sede
ORDER BY tasa_aprobacion DESC;


-- ============================================
-- INDICADOR ADICIONAL
-- Índice de Permanencia Estudiantil por Cohorte
-- Muestra cuántos estudiantes de cada generación 
-- siguen activos año a año por carrera.
-- Permite identificar patrones de abandono y 
-- diseñar estrategias de retención focalizadas.
-- ============================================

SELECT
  de.anio_ingreso AS cohorte,
  dc.nombre_carrera,
  dt.anio AS anio_cursado,
  COUNT(DISTINCT de.sk_estudiante) AS estudiantes_activos,
  SUM(fr.es_desercion) AS deserciones_ese_anio
FROM fact_rendimiento fr
JOIN dim_estudiante de ON fr.sk_estudiante = de.sk_estudiante
JOIN dim_curso dc ON fr.sk_curso = dc.sk_curso
JOIN dim_tiempo dt ON fr.sk_tiempo = dt.sk_tiempo
GROUP BY de.anio_ingreso, dc.nombre_carrera, dt.anio
ORDER BY cohorte, anio_cursado;
